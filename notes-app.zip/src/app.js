import "./style/style.css";
import home from "./scripts/view/home.js";
import "./scripts/components/index.js";
import "./scripts/validation.js";

home();
